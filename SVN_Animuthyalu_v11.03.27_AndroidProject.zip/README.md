# SVN Animuthyalu — v11.03.27
Luxury game hub bundling: JEE – The Topper Project, GYM GOD: The Final Rep, Flappy Face.

## Build the APK
**Option A – Android Studio:** File > Open this folder > wait for sync > Build > Build APK(s).
Output: app/build/outputs/apk/debug/app-debug.apk

**Option B – no PC setup (GitHub):** upload this folder to a new GitHub repo > Actions tab > "Build APK" > download the artifact.

## Edit
- Home page: app/src/main/assets/index.html (GAMES array at the top of the script)
- Games: app/src/main/assets/games/
- Min Android 5.0 (API 21), portrait, no permissions, works fully offline.
